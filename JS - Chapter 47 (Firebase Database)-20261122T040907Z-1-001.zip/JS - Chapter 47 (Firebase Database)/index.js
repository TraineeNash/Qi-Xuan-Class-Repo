// firebase and firestore cdn which provides methods for us to use
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import {
  getFirestore,
  collection,
  getDocs,
  Timestamp,
  addDoc,
  doc,
  deleteDoc,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";

// firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC69z3nF_mVB2lZJHkkvDy0yM-yDGmB-Rk",
  authDomain: "mon-recipe-app.firebaseapp.com",
  projectId: "mon-recipe-app",
  storageBucket: "mon-recipe-app.appspot.com",
  messagingSenderId: "642919181626",
  appId: "1:642919181626:web:9c44f6bd970de1b4a8f403",
};

/*
stabalise a connection between ur frontend (index.js) with ur backend (firebase dashboard), 
using "intializeApp()" provided by the CDN
*/
const app = initializeApp(firebaseConfig);

/*
    now we have a connection between frontend and backend --> "app", WE
    will use our database in our frontend using "getFirestore" by the CDN
*/
const db = getFirestore(app);



//--------------------------------------------------------------------
// Part 4 - delete document from our db when <button> clicked

//official doc to delete data --> https://firebase.google.com/docs/firestore/manage-data/delete-data

const ul = document.querySelector("ul");

//(i) add a "click" event listener on <ul>
ul.addEventListener("click", async (event) => {
  console.log(event.target.tagName);

  //(ii) find for the <button> inside the <ul>
  if (event.target.tagName == "BUTTON") {
    // if u click on the <button>, u want to delete. But how does delete work from db?
    // delete works BY PROVIDING THE ID.
    // question: where do we find this id? --> in the "data-id" attribute in <li>

    /*

    <li data-id="muDzPbh4UALfyTOSQ0hN">
              <div>Kebab</div>
              <div>Mon Aug 19 2024 21:16:10 GMT+0800 (Malaysia Time)</div>
              <button class="bg-red-500 hover:bg-red-660 text-white font-bold py-2 px-4 rounded-sm my-2">Delete</button>
    <li>    

    */

    // event.target = <button>
    // we need to go to the parent of the button --> <li>

    // (iii) once found, extract the "data-id" attribute from <li>
    const id = event.target.parentElement.getAttribute("data-id");

    //const id = muDzPbh4UALfyTOSQ0hN"

    // "try" --> because deleting data from db MIGHT/MIGHT NOT FAIL DUE TO SEVERAL REASONS, that's why we put inside try{}
    // "catch" --> IF ANY OF THE CODE INSIDE "try" fails, it will be caught by "catch"
    try {
      // doc() needs 3 inputs
      const docRef = doc(db, "recipes", id);
      await deleteDoc(docRef);
      console.log("Successfully delete doc with id " + docRef.id);
    } catch (error) {
      console.log(error);
    }
  }
});

//--------------------------------------------------------------------
// Part 6 - UI for deleting (removes the <li> from UI when button clicked)

const deleteRecipe =(id)=>{
  // (i) get all the <li> in the HTML
  const recipes = document.querySelectorAll("li");

  // (ii) loop through them, if the "data-id" matches "id" from function --> remove
  recipes.forEach(li=>{
      if(li.getAttribute("data-id") == id){
          li.remove() // remove the <li> with the id FROM THE UI
      }
  })
}

//----------------------------------------------------------------
// Part 3: UI for adding (displaying the docs' info into the <ul>)

// now that we get the documents info from the db, we can add them into our UI
// in order to do that..

// in this example, we are using this function 3 times
const addRecipe = (recipe, id) => {
  // create an <li> template to be inserted into the <ul>
  // 1 document = 1 <li>

  //attach custom data attribute "data-id" to each <li>
  // .toDate() --> converting the "createdAt" from (firebase timestamp) --> (JS date obj)

  //(i) create a <li> template and insert the recipe data into it
  let html = `
          <li data-id=${id}>
              <div>${recipe.title}</div>
              <div>${recipe.createdAt.toDate()}</div>
              <button class="bg-red-500 hover:bg-red-660 text-white font-bold py-2 px-4 rounded-sm my-2">Delete</button>
          <li>    
      `;

  // (ii) adding the created <li> into the parent <ul>
  ul.innerHTML += html;
};

//--------------------------------------------------------------------
// Part 5 - a problem

// now everything seems to work (add/delete) works!
// the problem, we need to refresh the page in order to see the UPDATED UI

// how can we solve this? --> LIVE LISTENER --> "live listener on each db snapshot"

// "View changes between snapshots" --> https://firebase.google.com/docs/firestore/query-data/listen

// whenever u add / delete things from db, the snapshot (picture of db) changes

// in Part2, we are not listening to the snapshot changes live

const fetchRecipesLive = async () => {

  // (i) get the 'recipes' collection using the [collection] function provided by the CDN
  const recipesCollection = collection(db, "recipes");

  // (ii) use the [onSnapshot] function provided by the CDN 

  /*
    onSnapshot() needs 2 inputs

    (1) which collection are u listening live?
    (2) cb function --> will run the cb function if there's any delete/add
  */

  // whenever u add / delete things from db, this cb function from the onSnapshot runs
  // whenever u add / delete things from db, a new snapshot is formed
  onSnapshot(recipesCollection,(snapshot)=>{

    //(iii) with the new formed snapshot, we loop through it 
    // for example if there are 3 docs in the new snapshot, it will loop through 3 times
    snapshot.docChanges().forEach((change) => {

      const doc = change.doc
      // there can be 2 types of changes (add, delete)
      if (change.type === "added") {
        // if "added", run the UI function of "addRecipe" to refresh UI live
        addRecipe(doc.data(), doc.id)
      }
      if (change.type === "removed") {
        // if "removed", run the UI function of "deleteRecipe" to refresh UI live
        deleteRecipe(doc.id)
      }
    });
  })

};

fetchRecipesLive();

//--------------------------------------------------------------------
// Part 2 - get documents of "RECIPES" collection

//official doc to get data --> https://firebase.google.com/docs/firestore/query-data/get-data

// in order to get documents from our db...

const fetchRecipes = async () => {
  // "try" --> because fetching data from db MIGHT/MIGHT NOT FAIL DUE TO SEVERAL REASONS, that's why we put inside try{}
  // "catch" --> IF ANY OF THE CODE INSIDE "try" fails, it will be caught by "catch"
  try {
    // (i) get the 'recipes' collection using the [collection] function provided by the CDN
    const recipesCollection = collection(db, "recipes");

    // (ii) get the documents inside this 'recipes' collection using the [getDocs] function provide by the CDN
    // you will get back a snapshot
    // snapshot - picture of your database (for example 3 documents inside the db)
    const snapshot = await getDocs(recipesCollection);

    // (iii) loop through the snapshot (in this example, the cb function will be looped 3 times)
    snapshot.forEach((doc) => {
      //(iv) displaying some info in our console just to see the result
      console.log(doc.id);
      console.log(doc.data());
      console.log("----");

      // (v) use the "addRecipe" (in this case, it will be used 3 times)
      // for example, if we have 3 docs in our db, this function will looped through 3 times
      // basically, adding 3 <li> into the <ul>
      addRecipe(doc.data(), doc.id);
    });
  } catch (error) {
    console.log(error);
  }
};

// comment this function call once we set up live listener in Part 5
// fetchRecipes();

//--------------------------------------------------------------------
// Part 1 - add document into the db

//official doc to add data --> https://firebase.google.com/docs/firestore/manage-data/add-data

// in order to add documents into our db...

const form = document.querySelector("form");

// (i) listening to the submit event of the <form>
form.addEventListener("submit", async (event) => {
  // (ii) prevent default behavior of refreshing
  event.preventDefault();

  // (iii) extract the "title" from the <form>
  const userInput = form.recipe.value.trim();
  // console.log(userInput)

  // (iv) create a current date object as the "createdAt"
  const now = new Date(); // JS Date Object

  // (v) construct an object to be added into our db
  const recipe = {
    title: userInput,
    createdAt: Timestamp.fromDate(now),
    // converting the data from (JS date obj) --> (firebase timestamp)
  };

  // console.log(recipe)

  // (vi) reset the form
  form.reset();

  // (vii) send this "recipe" JSON object to our database

  // "try" --> because sending data to db MIGHT/MIGHT NOT FAIL DUE TO SEVERAL REASONS, that's why we put inside try{}
  // "catch" --> IF ANY OF THE CODE INSIDE "try" fails, it will be caught by "catch"
  try {
    // get the 'recipes collection
    const recipesCollection = collection(db, "recipes");
    const docRef = await addDoc(recipesCollection, recipe);
    console.log("Document written with ID: ", docRef.id);
  } catch (error) {
    console.log(error);
  }
});
